import requests
import json


class YoutubeVideo():
    key = 'AIzaSyAnb6pEXjtfA03Orr_BgdRMsMUKQV8SnO0'
    def fetchVideos(self):
        max = 10
        params = {'part':'snippet,id,contentDetails, statistics','maxResults':max,'videoId':'',\
            'chart':'mostPopular', 'regionCode':'IN', 'key':self.key\
            } 
        r = requests.get(url = 'https://www.googleapis.com/youtube/v3/videos', params = params)
        print("Status Code : ",r.status_code)
        data = json.loads(r.text)
        for video in range(0, max):
            print('======================='*5)
            print("Video Id : ",data["items"][video]["id"]) # video id
            print("Video Url : https://www.youtube.com/watch?v="+str(data["items"][video]["id"]))
            print("Title : ",data["items"][video]["snippet"]["title"]) # title
            print("Category : ",data["items"][video]["snippet"]["categoryId"])  #category
            print("Rating : ",data["items"][video]["statistics"])
        print('======================='*5)        
    
if __name__ == "__main__":
    yt = YoutubeVideo()
    yt.fetchVideos()