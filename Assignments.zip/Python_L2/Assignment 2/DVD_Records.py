import MySQLdb
import os

def connectMySQL(hst=None, usr=None, pwd=None, dbase=None, prt=None):
    con = None
    if not hst:
        hst = "127.0.0.1"
    if not usr:
        usr = "root"
    if not prt:
        prt = 3306
    if not dbase and not pwd:
        con = MySQLdb.connect(host=hst, user=usr, port=prt)
    elif dbase and not pwd:
        con = MySQLdb.connect(host=hst, user=usr, db=dbase, port=prt)
    elif not dbase and pwd:
        con = MySQLdb.connect(host=hst, user=usr, passwd=pwd, port=prt)
    else:
        con = MySQLdb.connect(host=hst, user=usr, passwd=pwd, db=dbase, port=prt)
    return con


def createDatabase(con, db):
    cursor = con.cursor()
    sql = "CREATE DATABASE " + db + ";"
    cursor.execute(sql)
    cursor.close()


def createTable(con, table):
    cursor = con.cursor()
    sql = "CREATE TABLE " + table + """(
        TITLE VARCHAR(20) PRIMARY KEY,
        STAR_NAME VARCHAR(50) NOT NULL,
        YEAR_OF_RELEASE INT(4) NOT NULL,
        GENRE VARCHAR(10) NOT NULL
        );"""
    cursor.execute(sql)
    cursor.close()


def dropTable(con, table):
    cursor = con.cursor()
    sql = "DROP TABLE " + table + ";"
    cursor.execute(sql)
    cursor.close()


def addDVD(con, table, title, star, year, genre):
    cursor = con.cursor()
    sql = "INSERT INTO TABLE " + table + " VALUES ("+ title + "," + star + "," + year + "," + genre")"
    cursor.execute(sql)
    cursor.close()


def modifyDVD(con, table, title, star=None, year=None, genre=None):
    cursor = con.cursor()
    if star:
        sql = "UPDATE TABLE " + table + """
                SET STAR_NAME = """ + star + """
                WHERE TITLE = """ + title + ";"
        cursor.execute(sql)
    if year:
        sql = "UPDATE TABLE " + table + """
                SET YEAR_OF_RELEASE = """ + year + """
                WHERE TITLE = """ + title + ";"
        cursor.execute(sql)
    if genre:
        if star:
            sql = "UPDATE TABLE " + table + """
                    SET STAR_NAME = """ + star + """
                    WHERE TITLE = """ + title + ";"
            cursor.execute(sql)
    cursor.close()


def deleteDVD(con, table, title):
    cursor = con.cursor()
    sql = "DELETE FROM " + table + "WHERE TITLE = " + title + ";"
    cursor.execute(sql)
    cursor.close()


def searchByTitle(con, table, title):
    cursor = con.cursor()
    sql = "SELECT * FROM " + table + "WHERE TITLE LIKE '%" + title + "%' ;"
    cursor.execute(sql)
    cursor.close()
    return cursor.fetchall()


def searchByYear(con, table, year):
    cursor = con.cursor()
    sql = "SELECT * FROM " + table + "WHERE YEAR_OF_RELEASE = " + year + " ;"
    cursor.execute(sql)
    cursor.close()
    return cursor.fetchall()


def searchByCast(con, table, cast):
    cursor = con.cursor()
    sql = "SELECT * FROM " + table + "WHERE STAR_NAME LIKE '%" + cast + "%' ;"
    cursor.execute(sql)
    cursor.close()
    return cursor.fetchall()


def searchByGenre(con, table, genre):
    cursor = con.cursor()
    sql = "SELECT * FROM " + table + "WHERE GENRE = " + genre + " ;"
    cursor.execute(sql)
    cursor.close()
    return cursor.fetchall()


def getGenres(con, table):
    cursor = con.cursor()
    sql = "SELECT DISTINCT GENRE FROM " + table + " ;"
    cursor.execute(sql)
    cursor.close()
    return cursor.fetchall()


def addDVD(con, table):
    title = raw_input("Enter DVD Title :- ")
    cast = raw_input("Enter star cast :- ")
    year = raw_input("Enter it's year of release :- ")
    genre = raw_input("Entre Genre :- ").lower()
    addDVD(con, table, title, cast, year, genre)
    
    
def modifyDVD(con, table):
    title = raw_input("Enter DVD Title to modify :- ")
    cast = raw_input("Enter modified cast (leave blank if not want to modify) :- ")
    year = raw_input("Enter modified year if release (leave blank if not want to modify) :- ")
    genre = raw_input("Enter modified genre (leave blank if not want to modify) :- ")
    modifyDVD(con, table, title, cast, year, genre)
    
    
def delDVD(con, table):
    title = raw_input("Enter DVD Title to delete :- )
    deleteDVD(con, table, title)
    
    
def searchTitle(con, table):
    title = raw_input("Enter DVD Title to search :- )
    result = searchByTitle(con, table, title)
    printResult(result)
    
    
def searchCast(con, table):
    cast = raw_input("Enter cast to search :- )
    result = searchByCast(con, table, cast)
    printResult(result)
    
    
def searchYear(con, table):
    year = raw_input("Enter cast to search :- )
    result = searchByYear(con, table, year)
    printResult(result)
    
    
def searchGenre(con, table, choice):
    result = searchByGenre(con, table, choice)
    printResult(result)
    
    
def menu():
    print("DVD STORE\n")
    print("1. Add a DVD")
    print("2. Search")
    print("3. Modify a DVD")
    print("4. Delete a DVD")
    print("5. Exit\n")
    choice = raw_input("Enter your choice :- ")
    return choice
    

def searchMenu():
    print("Select an option\n")
    print("1. Title")
    print("2. Cast")
    print("3. Year")
    print("4. Genre")
    choice = raw_input("Enter your choice :- ")
    return choice
    
    
def searchGenreMenu():
    print("Select Genre\n")
    genres = getGenre(con, table)
    i = 1;
    for genre in genres:
        print(str(i) + ". " + genre)
        i++
    choice = raw_input("Enter your choice :- ")
    if(choice <= 0 && choice > genres.length):
        return None
    return genres[choice]
    
    
def printResult(result_list):
    return

    

def clearScreen():
    os.system('tput reset');

db = raw_input("Enter databse (default is 'test', leave blank for default) to connect to :- ");
user = raw_input("Enter the username (default is 'root', leave blank for default) for connectivity :- ");
pswd = raw_input("Enter password (default is no password, leave blank for default) for connectivity :- ");
host = raw_input("Enter hostname (default is localhost, leave blank for default) for connectivity :- ");
port = raw_input("Enter port (default is 3306, leave blank for default) for connectivity :- ");

print("")
if not db:
    db = "test"
clearScreen()

try:
    con = connectMySQL(hst=host, usr=user, pwd=pswd, dbase=db, prt=port)
    print("[+] Connected to Database '" + db + "'")
except Exception as e:
    print("[-] Failed to connect")
    if(e[0] == 1049):
        print("[-] Error :- Database '" + db + "' doesn't exists")
        print("")
        print("[+] Attempting to create Database '" + db + "'")
        con = connectMySQL(hst=host, usr=user, pwd=pswd, prt=port)
        createDatabase(con, db)
        print("[+] Database '" + db + "' successfully Created")
        print("[+] Attempting to connect to Databse '" + db + "'")
        con.cursor().execute("use " + db + ";")
        print("[+] Connected to Database '" + db + "'")
    else:
        print("[-] Error :- " + e[1])
        exit()


table = raw_input("Enter name of the table to be created : ")
try:
    createTable(con, table)
    print("[+] Table '" + table + "' Created Successfully")
except Exception as e:
    print("[-] Failed to create Table '" + table + "'")
    if(e[0] == 1050):
        print("[-] Error :- Table '" + table + "' already exists")
        print("")
        conf = raw_input("*** Do you want to drop existing Table '" + table + "'\n   (WARNING This will erase all the data as well)\n   Write YES (in caps) to confirm  :  ")
        if(conf == "YES"):
            conf = raw_input("**** You are about to delete Table '" + table + "'\n    Press Y and Enter to continue any other key and Enter to stop :- ")
            if(conf == "Y" or conf == "y"):
                print("[+] Dropping Table '" + table + "'")
                dropTable(con, table)
                print("[+] Successfully Dropped Table '" + table + "'")
                print("[+] Attempting to create Table '" + table + "'")
                createTable(con, table)
                print("[+] Successfully created Table '" + table + "'")
            else:
                print("[-] You stopped the dropping command")
                print("[-] Can't continue since '" + table + "' already exists")
                exit()
        else:
            print("[-] Can't continue since '" + table + "' already exists")
            exit()
    else:
        print("[-] Error :- " + e[1])
clearScreen()
con.close()
