import socket

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

port = 1234
server = "127.0.0.1"

while True:
    try:
        client.connect((server, port))
        break
    except ConnectionRefusedError:
        pass

print (client.recv(1024))

client.close()
