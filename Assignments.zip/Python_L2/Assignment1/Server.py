import socket
import threading

try:
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    print("Server started successfully")
except socket.error as error:
    print("Server couldn't start :- " + error)
    exit()

conn = None
#port used for connecting
port = 1234
server.bind(('',port))
print("Server binded to port " + str(port))

server.listen()
print("Server is listening")

while True:

    try:
        conn, addr = server.accept()
        print("Got connection from ", addr)

        conn.send(b'Connected Successfully')
        conn.close()
    except KeyboardInterrupt:
        if conn:
            conn.close()
        print()
        exit()
