import smtplib
import imaplib
import email
import xlrd
import smtplib, ssl
from time import sleep

class emailVerification():
    RECEIVE_SERVER = 'imap.gmail.com'
    RECEIVER_PORT = 993
    SEND_SERVER = 'smtp.gmail.com'
    SEND_PORT = 587
    USERNAME = 'trendnxtexam@gmail.com'
    PASSWORD = 'trendnxtexam@123'
    FILE_PATH = 'database.xlsx'
    DEFAULT_MESSAGE = """\
        USER IS NOT REGISTERED IN THE SYSTEM."""
    
    def authenticate(self):
        try:
            imap = imaplib.IMAP4_SSL(self.RECEIVE_SERVER, self.RECEIVER_PORT)
            imap.login(self.USERNAME, self.PASSWORD) 
            imap.select('INBOX')
            status, response = imap.search(None, '(UNSEEN)', 'SUBJECT', '"BANK"')
        except Exception as AuthenticationError:
            print(AuthenticationError)
        self.mails(imap,response)
        print("Done")
        return None

    def mails(self, imap, response):
        unread_msg_nums = response[0].split()
        # Print the count of all unread messages
        print (len(unread_msg_nums), 'New Mails Found')
        user_list = []
        for e_id in unread_msg_nums:
            _, response = imap.fetch(e_id, '(BODY[HEADER.FIELDS (FROM)])')
            out = response[0][1].decode('utf-8')
            user_list.append(out)
        if len(user_list) == 0:
            return None

        for user in range(len(user_list)):
            sender = ''
            start = user_list[user].find('<')
            end = user_list[user].find('>')
            for i in range(start+1, end):
                sender+=user_list[user][i]
            self.verifyUser(sender)
            print("---- ---- "*7)
        return

    def verifyUser(self, sender):
        print("Verifying %s with bank's database"%(sender))
        wb = xlrd.open_workbook(self.FILE_PATH) 
        sheet = wb.sheet_by_index(0)
        sheet.cell_value(0,0)
        flag = False
        for i in range(sheet.nrows):
            if sheet.cell_value(i, 0) == sender:
                flag = True
                break
        if flag == True:
            print("Valid User")
            userData = sheet.row_values(i)[1]
            message = """\
                Subject: BANK
                Customer Id : %s""" %(userData)
            self.sendMail(sender,message)
        else:
            print("Invalid User")
            self.sendMail(sender,self.DEFAULT_MESSAGE)
        return
    
    def sendMail(self, sender, message):
        context = ssl.create_default_context()
        with smtplib.SMTP(self.SEND_SERVER, self.SEND_PORT) as server:
            server.ehlo()  # Can be omitted
            server.starttls(context=context)
            server.ehlo()  # Can be omitted
            server.login(self.USERNAME, self.PASSWORD)
            server.sendmail(self.USERNAME, sender, message)
        return

if __name__ == "__main__":
    while True:
        print("Checking for new mails...")
        trigger = emailVerification()
        trigger.authenticate()
        sleep(60)